//
//  CoinManager.swift
//  ByteCoin
//
//  Created by Angela Yu on 11/09/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import Foundation

protocol CoinManagerDelegate : AnyObject{
    func didFailWithError(error: Error)
    func didGetPrice(_ coinManager: CoinManager, coin: CoinModel, currency: String)
}

struct CoinManager {
    
    let baseURL = "https://rest.coinapi.io/v1/exchangerate/BTC"
    let apiKey = "DD47F2F5-CB88-4532-B290-2C7890378396"
    
    let currencyArray = ["AUD", "BRL","CAD","CNY","EUR","GBP","HKD","IDR","ILS","INR","JPY","MXN","NOK","NZD","PLN","RON","RUB","SEK","SGD","USD","ZAR"]
    
    weak var delegate: CoinManagerDelegate?
    
    func getCoinPrice(for currency: String) {
        let urlString = "\(baseURL)/\(currency)?apikey=\(apiKey)" //Simply concatinate with string
        // print(urlString)
        performRequest(with: urlString,currency: currency)
    }
    
    func performRequest(with urlString: String,currency:String)
    {
        // 1) Create URL, 2) Create URLSession, 3) Give URLSession a Task 4) Start the task
        
        
        //1. Create a URL
        
        if let url = URL(string: urlString) {
            
            //2. Create a URLSession
            
            let session = URLSession(configuration: .default) //goes here in case of wrong
            
            //3. Give a URLSession Task
            
            let task = session.dataTask(with: url) { data, response, error in
                if error != nil{
                    // print(response ?? "no response")
                    self.delegate?.didFailWithError(error: error!)
                    return
                }
                
                if let safeData = data {
                    //  print(String(data: safeData, encoding: .utf8))
                    if let coin = self.parseJSON(safeData){
                        self.delegate?.didGetPrice(self, coin: coin, currency: currency)
                    }
                } //All this is closure body
            }
            //4. Start the task
            task.resume()
        }
    }
    
    func parseJSON(_ coinData: Data) -> CoinModel?
    {
        let decoder = JSONDecoder()
        do{
            let decodeData = try decoder.decode(CoinData.self, from: coinData)
            let lastPrice = decodeData.rate
            let coin = CoinModel(rate: lastPrice)
            return coin
        } catch{
            self.delegate?.didFailWithError(error: error)
            return nil
        }
    }
    
}
