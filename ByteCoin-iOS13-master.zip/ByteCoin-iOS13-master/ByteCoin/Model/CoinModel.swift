//
//  CoinModel.swift
//  ByteCoin
//
//  Created by Muhammad Shaeel Abbas on 17/04/2022.
//  Copyright © 2022 The App Brewery. All rights reserved.
//

import Foundation
struct CoinModel { //Weather class
    //WeatherModel holds onto WeatherData?
    let rate : Double
    
}
