//
//  Coin.swift
//  ByteCoin
//
//  Created by Muhammad Shaeel Abbas on 17/04/2022.
//  Copyright © 2022 The App Brewery. All rights reserved.
//

import Foundation
struct CoinData : Decodable { //Used later for Weather object
    let rate: Double
}
